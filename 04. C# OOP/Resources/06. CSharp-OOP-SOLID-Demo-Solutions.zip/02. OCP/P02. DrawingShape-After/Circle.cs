﻿namespace P02._DrawingShape_After
{
    using Contracts;

    public class Circle : IShape
    {
    }
}
