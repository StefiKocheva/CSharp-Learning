﻿namespace P02._DrawingShape_After.Contracts
{
    public interface IShape
    {
    }
}
