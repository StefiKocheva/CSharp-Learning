﻿namespace P01._DrawingShape_After.Contracts
{
    public interface IDrawingManager
    {
        void Draw(IShape shape);
    }
}
