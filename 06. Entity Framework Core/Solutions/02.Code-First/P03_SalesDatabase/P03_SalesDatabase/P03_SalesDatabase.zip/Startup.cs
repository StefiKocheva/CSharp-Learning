﻿namespace P03_SalesDatabase
{
    using System;

    public static class Startup
    {
        public static void Main()
        {
        }
    }
}
